import json

def handler(event, context):
    message = "hello team"

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body" : json.dumps(message)
    }