import json

def handler(event, context):
    message = "initial code"

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body" : json.dumps(message)
    }